
public class Rectangle implements Shape {
	public void draw() {}
}
