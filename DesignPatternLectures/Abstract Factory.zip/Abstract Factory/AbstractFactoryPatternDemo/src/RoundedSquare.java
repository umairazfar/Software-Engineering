
public class RoundedSquare implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub

	}

}
