
public class RoundedRectangle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub

	}

}
